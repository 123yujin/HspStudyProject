package com.cwy.qqserver.service;

import java.io.IOException;
import java.io.ObjectOutputStream;

public class OffOnlineMessageThread implements Runnable{
    private boolean isAlive = true;
    static String getter;

    @Override
    public void run() {

        while (isAlive){
            if(ManageClientThreads.getHm().containsKey(getter)){
                try {
                    ObjectOutputStream oos = new ObjectOutputStream(ManageClientThreads.getSeverConnectClientThread(getter).getSocket().getOutputStream());
                    oos.writeObject(OffMessageHashMap.getUm().get(getter));
                    OffMessageHashMap.removeOffMessage(getter);
                    isAlive = false;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
