package com.cwy.qqframe;

import com.cwy.qqserver.service.QQServer;

import java.io.IOException;

public class QQFrame {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        new QQServer();
    }
}
